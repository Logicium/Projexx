
public class DeadlineObject {

}
