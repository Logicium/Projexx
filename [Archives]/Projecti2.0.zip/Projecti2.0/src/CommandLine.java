
public class CommandLine {

	//A function that begins when the author is working on a file,
	//Command line gives access to adding new projects, deleting projects, changing settings
	//Settings like the Clock refresh rate, the  
	
	//Check for flags first and last
	public void converse() throws InterruptedException{
	
	CoreData.print("Entering command line mode...");
	CoreData.print("Type 'quit' to quit.");
	if(Settings.helpReminder.state == true){
		
		
	}
	
	boolean continueFlag = true;
	
	while(continueFlag){
			
		
	}
	
	}
	
	
}
