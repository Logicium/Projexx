
public class Settings {

	public static FlagObject helpReminder = new FlagObject("Command Line Help Reminder",1,true);
	
}
